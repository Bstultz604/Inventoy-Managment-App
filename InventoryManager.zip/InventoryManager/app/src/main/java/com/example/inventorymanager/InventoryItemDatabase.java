package com.example.inventorymanager;

import android.content.Context;
import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

@Database(entities = {InventoryItem.class, User.class}, version = 2)
public abstract class InventoryItemDatabase extends RoomDatabase{

    private static final String DATABASE_NAME = "InventoryItems.db";

    private static InventoryItemDatabase itemDatabase;

    //Singleton
    public static InventoryItemDatabase getInstance(Context context){
        if(itemDatabase == null){
            itemDatabase = Room.databaseBuilder(context, InventoryItemDatabase.class,
                    DATABASE_NAME).fallbackToDestructiveMigration().allowMainThreadQueries().build();
        }
        return itemDatabase;
    }

    //public abstract UserDao userDao();
    public abstract ItemDao itemDao();
    public abstract UserDao userDao();
}
