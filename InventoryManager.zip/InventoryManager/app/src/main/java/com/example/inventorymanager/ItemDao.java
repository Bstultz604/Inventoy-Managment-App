package com.example.inventorymanager;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
import androidx.room.Update;
import java.util.List;

@Dao
public interface ItemDao {

    @Query("SELECT * FROM items WHERE user=:username ORDER BY name")
    public List<InventoryItem> getItems(String username);

    @Query("UPDATE items SET qty=:newQty WHERE user=:user AND name=:itemName")
    public void editItem(String user ,int newQty, String itemName);

    @Query("SELECT * FROM items WHERE user=:user AND name=:itemName")
    public InventoryItem findItem(String user, String itemName);

    @Insert(onConflict = OnConflictStrategy.FAIL)
    public void insertItem(InventoryItem item);

    @Update
    public void updateItem(InventoryItem item);

    @Delete
    public void deleteItem(InventoryItem item);
}
