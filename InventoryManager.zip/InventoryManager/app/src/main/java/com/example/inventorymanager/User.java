package com.example.inventorymanager;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "users")

public class User {

    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "userName")
    private String userName;

    @ColumnInfo(name = "password")
    private String userPassword;

    public User(){};

    public User(String name, String password){
        userName = name;
        userPassword = password;
    }


    //Setter & Getter Methods
    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserName(){
        return userName;
    }

    public void setUserPassword(String password){
        userPassword = password;
    }

    public String getUserPassword(){
        return userPassword;
    }
}
