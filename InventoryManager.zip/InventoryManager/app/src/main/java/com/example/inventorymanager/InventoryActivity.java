package com.example.inventorymanager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Parcelable;
import android.text.TextUtils;
import android.util.Log;
import android.view.ActionMode;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.Serializable;
import java.util.List;


public class InventoryActivity extends AppCompatActivity
        implements ItemDialogFragment.OnItemEnteredListener{

    private final static String TAG = "InventoryActivity";

    private InventoryItemDatabase itemDb;
    private ItemAdapter itemAdapter;
    private RecyclerView recyclerView;

    private InventoryItem selectedItem;
    private int selectedItemPos = RecyclerView.NO_POSITION;
    private ActionMode actionMode = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        Intent intent = getIntent();

        Log.i(TAG, "OnCreate called");
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        //Initializes our database for use
        //Singleton
        itemDb = InventoryItemDatabase.getInstance(getApplicationContext());

        //Links and Initializes our recyclerview for use
        recyclerView = findViewById(R.id.itemRecyclerView);

        //Create 2 grid layout columns
        RecyclerView.LayoutManager gridLayoutManager =
                new GridLayoutManager(getApplicationContext(), 2);
        recyclerView.setLayoutManager(gridLayoutManager);

        //Show All items
        itemAdapter = new ItemAdapter(loadItems());
        recyclerView.setAdapter(itemAdapter);
    }

    @Override
    protected void onResume(){
        super.onResume();

        Log.i(TAG, "OnResume called");
        itemAdapter = new ItemAdapter(loadItems());
        recyclerView.setAdapter(itemAdapter);
    }

    private List<InventoryItem> loadItems(){

        String user = getIntent().getStringExtra("username");

        return itemDb.itemDao().getItems(user);
    }

    @Override
    public void onItemEntered(String user, String item, int qty){
        //Returns item entered in ItemDialogFragment dialog
        if(itemDb.itemDao().findItem(user, item) != null){
            String message = getResources().getString(R.string.item_exists, item);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }

        if(!TextUtils.isEmpty(item) && itemDb.itemDao().findItem(user, item) == null){
            InventoryItem newItem = new InventoryItem(user, item, qty);
            itemAdapter.addItem(newItem);
            itemDb.itemDao().insertItem(newItem);
        }
        if(TextUtils.isEmpty(item)){
            String message = getResources().getString(R.string.no_item_name);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }

        else{
            String message = getResources().getString(R.string.item_exists, item);
            Toast.makeText(this, message, Toast.LENGTH_LONG).show();
        }
    }

    public void addItemClick(View view){
        //prompt user to type new item and initial qty
        FragmentManager manager = getSupportFragmentManager();
        ItemDialogFragment dialog = new ItemDialogFragment();

        Bundle user = new Bundle();
        user.putString("user", getIntent().getStringExtra("username"));
        dialog.setArguments(user);

        dialog.show(manager, "itemDialog");

    }

    public boolean onCreateOptionsMenu(Menu menu){
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.item_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //Handle item Selection
        switch(item.getItemId()){
            case R.id.settings:
                Intent intent = new Intent(InventoryActivity.this, SettingsActivity.class);
                startActivity(intent);
                return true;

            default:
                return super.onOptionsItemSelected(item);
                }

    }

    //---------------------------HOLDER---------------------------------
    private class ItemHolder extends RecyclerView.ViewHolder
        implements View.OnClickListener, View.OnLongClickListener{

        private InventoryItem item;
        private TextView nameTextView;
        private TextView qtyTextView;


        public ItemHolder(LayoutInflater inflater, ViewGroup parent){
            super(inflater.inflate(R.layout.recycler_view_items, parent, false));
                    itemView.setOnClickListener(this);
                    nameTextView = itemView.findViewById(R.id.itemNameTextView);
                    qtyTextView = itemView.findViewById(R.id.itemQtyTextView);

                    itemView.setOnLongClickListener(this);
                    itemView.setOnClickListener(this);
        }

        public void bind(InventoryItem item, int position){
            this.item = item;
            nameTextView.setText(item.getItemName());
            qtyTextView.setText(String.valueOf(item.getItemQty()));

            if(selectedItemPos == position){
                //Make Selected subject stand out
                nameTextView.setBackgroundColor(Color.RED);
            }
            else{
                nameTextView.setBackgroundColor(Color.BLUE);
            }
        }

        @Override
        public boolean onLongClick(View view){
            if(actionMode != null){
                return false;
            }

            selectedItem = item;
            selectedItemPos = getAdapterPosition();

            //re-bind teh selected item
            itemAdapter.notifyItemChanged(selectedItemPos);

            //show the CAB
            actionMode = InventoryActivity.this.startActionMode(ActionModeCallback);

            return true;
        }

        @Override
        public void onClick(View view){
            //Start ItemActivity, indicating what item was clicked
            Intent intent = new Intent(InventoryActivity.this, EditItemActivity.class);

            String itemName = (String) nameTextView.getText();
            String itemQty = (String)  qtyTextView.getText();

            String user = getIntent().getStringExtra("username");

            Bundle extras = new Bundle();
            extras.putString("user", user);
            extras.putString("editItemName", itemName);
            extras.putString("editItemQty", itemQty);

            intent.putExtras(extras);
            startActivity(intent);
        }

        private ActionMode.Callback ActionModeCallback = new ActionMode.Callback() {

            @Override
            public boolean onCreateActionMode(ActionMode mode, Menu menu) {
                //Provide context menu for CAB
                MenuInflater inflater = mode.getMenuInflater();
                inflater.inflate(R.menu.context_menu, menu);
                return true;
            }

            @Override
            public boolean onPrepareActionMode(ActionMode actionMode, Menu menu) {
                return false;
            }

            @Override
            public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
               //process action item selection
                switch (item.getItemId()){
                    case R.id.delete:
                        //Delete from data base and remove from recyclerview
                        itemDb.itemDao().deleteItem(selectedItem);
                        itemAdapter.removeItem(selectedItem);

                        //Close the CAB
                        mode.finish();
                        return true;

                    default:
                        return false;
                }
            }

            @Override
            public void onDestroyActionMode(ActionMode mode) {
                actionMode = null;

                //CAB closing, need to deselect item if not deleted;
                itemAdapter.notifyItemChanged(selectedItemPos);
                selectedItemPos = RecyclerView.NO_POSITION;
            }
        };
    }

    //-----------------------------ADAPTER------------------------------
    private class ItemAdapter extends RecyclerView.Adapter<ItemHolder>{

        private List<InventoryItem> itemList;

        public ItemAdapter(List<InventoryItem> items){itemList = items;}

        @Override
        public ItemHolder onCreateViewHolder(ViewGroup parent, int viewType){
            LayoutInflater layoutInflater = LayoutInflater.from(getApplicationContext());
            return new ItemHolder(layoutInflater, parent);
        }

        @Override
        public void onBindViewHolder(ItemHolder holder, int pos){
            holder.bind(itemList.get(pos), pos);
        }

        @Override
        public int getItemCount(){return itemList.size();}

        public void addItem(InventoryItem item){
            //Add the new item at the beginning of the list
            itemList.add(0, item);

            //Notify the adapter that item was added to beginning of list
            notifyItemInserted(0);

            //Scroll to teh top
            recyclerView.scrollToPosition(0);
        }

        public void removeItem(InventoryItem item){
            //Find item in the list
            int index = itemList.indexOf(item);

            if(index >= 0){
                //Remove the subject
                itemList.remove(index);

                //Notify adapter of item removal
                notifyItemRemoved(index);
            }
        }
    }
}