package com.example.inventorymanager;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(tableName = "items",
    foreignKeys = @ForeignKey(entity = User.class,
                parentColumns = "userName",
                childColumns = "user"))

public class InventoryItem {
    @PrimaryKey
    @NonNull
    @ColumnInfo(name = "name")
    private String itemName;

    @ColumnInfo(name = "user")
    private String user;

    @ColumnInfo(name = "qty")
    private int itemQty;

    public InventoryItem(){};

    public InventoryItem(String user ,String name, int qty){

        this.user = user;
        itemName = name;
        itemQty = qty;
    }

    public void setItemName(String name){
        itemName = name;
    }

    public String getItemName(){
        return itemName;
    }

    public void setUser(String user){
        this.user = user;
    }

    public String getUser(){
        return user;
    }

    public void setItemQty(int qty){
        itemQty = qty;
    }

    public int getItemQty(){
        return itemQty;
    }
}
