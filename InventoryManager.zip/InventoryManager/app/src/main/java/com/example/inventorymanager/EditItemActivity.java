package com.example.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;

public class EditItemActivity extends AppCompatActivity {

    private InventoryItemDatabase itemDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Bundle extra = getIntent().getExtras();
        setContentView(R.layout.activity_edit_item);

        TextView editItemName = findViewById(R.id.editItemName);
        EditText editQty = findViewById(R.id.editQty);

        editItemName.setText(extra.getString("editItemName"));

        editQty.setText(extra.getString("editItemQty"));
    }

    public void addOne(View view){

        EditText editQty = findViewById(R.id.editQty);

        int qty = Integer.parseInt(editQty.getText().toString());

        ++qty;

        editQty.setText(String.valueOf(qty));
    }

    public void minusOne(View view){

        EditText editQty = findViewById(R.id.editQty);

        int qty = Integer.parseInt(editQty.getText().toString());

        --qty;

        editQty.setText(String.valueOf(qty));

    }

    public void confirm(View view){
        itemDb = InventoryItemDatabase.getInstance(getApplicationContext());

        String user = getIntent().getStringExtra("user");

        EditText editQty = findViewById(R.id.editQty);
        TextView editItemName = findViewById(R.id.editItemName);

        String name = editItemName.getText().toString();
        int qty = Integer.parseInt(editQty.getText().toString());

        itemDb.itemDao().editItem(user, qty, name);

        Intent intent = new Intent(EditItemActivity.this, InventoryActivity.class);
        intent.putExtra("username", user);
        startActivity(intent);
    }

    public void cancel(View view){
        String user = getIntent().getStringExtra("user");

        Intent intent = new Intent(EditItemActivity.this, InventoryActivity.class);
        intent.putExtra("username", user);
        startActivity(intent);
    }
}