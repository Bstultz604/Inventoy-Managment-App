package com.example.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

public class NewAccountActivity extends AppCompatActivity {

    private InventoryItemDatabase itemDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_account);

        itemDb = InventoryItemDatabase.getInstance(getApplicationContext());
    }

    public void createAccount(View view) throws InterruptedException {
        EditText newUserName = findViewById(R.id.newAccountUserName);
        EditText newPassword = findViewById(R.id.newAccountPassword);
        EditText confirmPassword = findViewById(R.id.newAccountPasswordConfirm);

       if(!newPassword.getText().toString().equals(confirmPassword.getText().toString())){
           Snackbar passwordError = Snackbar.make(view, R.string.password_error, BaseTransientBottomBar.LENGTH_SHORT);
           passwordError.show();
       }
       if((itemDb.userDao().getUser(newUserName.getText().toString(), newPassword.getText().toString())) == null){

           User newUser = new User();

           newUser.setUserName(newUserName.getText().toString());
           newUser.setUserPassword(newPassword.getText().toString());
           itemDb.userDao().insertUser(newUser);

           Snackbar accountCreated = Snackbar.make(view, R.string.account_created, BaseTransientBottomBar.LENGTH_LONG);
           accountCreated.show();


           Intent intent = new Intent(NewAccountActivity.this, LoginActivity.class);
           intent.putExtra("new_account", 1);
           startActivity(intent);
       }
       else{
           Snackbar userError = Snackbar.make(view, R.string.user_error, BaseTransientBottomBar.LENGTH_SHORT);
           userError.show();
       }
    }


    public void cancelAccount(View view){
        Intent intent = new Intent(NewAccountActivity.this, LoginActivity.class);
        startActivity(intent);
    }
}