package com.example.inventorymanager;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.snackbar.BaseTransientBottomBar;
import com.google.android.material.snackbar.Snackbar;

public class LoginActivity extends AppCompatActivity {

    InventoryItemDatabase itemDb;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        itemDb = InventoryItemDatabase.getInstance(getApplicationContext());
    }

    @Override
    protected void onResume(){
        super.onResume();

        int newAccount = getIntent().getIntExtra("new_account", 0);

        if(newAccount == 1) {
            Toast accountCreated = Toast.makeText(getApplicationContext(), R.string.account_created, Toast.LENGTH_LONG);
            accountCreated.show();
            newAccount = 0;
        }

    }

    public void toMainPage(View view){

        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);

        if(itemDb.userDao().getUser(username.getText().toString(), password.getText().toString()) == null){
            Context context = getApplicationContext();
            CharSequence text = "Account not found";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, text, duration);
            toast.show();
        }
        else{

            String user = username.getText().toString();
            Intent intent = new Intent(LoginActivity.this, InventoryActivity.class);
            intent.putExtra("username", user);
            startActivity(intent);

        }
    }

    public void createNewAccount(View view){
        Intent intent = new Intent(LoginActivity.this, NewAccountActivity.class);
        startActivity(intent);
    }
}